#DONT INCLUDE THIS FILE WITH YOUR GITHUB.
def getVirusTotalApiKey():
    return "7a8f96b2bd17a58dece27c34feb4c104d4d7859331ba02bf04d3cc0da884d53e"